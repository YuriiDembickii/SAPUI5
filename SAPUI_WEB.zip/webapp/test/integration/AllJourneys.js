/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"SAP/SAPUI_WEB/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"SAP/SAPUI_WEB/test/integration/pages/Worklist",
	"SAP/SAPUI_WEB/test/integration/pages/Object",
	"SAP/SAPUI_WEB/test/integration/pages/NotFound",
	"SAP/SAPUI_WEB/test/integration/pages/Browser",
	"SAP/SAPUI_WEB/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "SAP.SAPUI_WEB.view."
	});

	sap.ui.require([
		"SAP/SAPUI_WEB/test/integration/WorklistJourney",
		"SAP/SAPUI_WEB/test/integration/ObjectJourney",
		"SAP/SAPUI_WEB/test/integration/NavigationJourney",
		"SAP/SAPUI_WEB/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});